﻿using ClaimsService.Models;
using ClaimsService.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClaimsController : ControllerBase
    {
        private readonly IClaimService claimService;
        public ClaimsController(IClaimService claimService)
        {
            this.claimService = claimService;
        }

        [HttpGet]
        [Route("memberclaims")]
        public async Task<IActionResult> GetMemberClaimDetails([FromQuery] string dateby)
        {
            if(!DateTime.TryParse(dateby, out DateTime toDateBy))
            {
                toDateBy = DateTime.UtcNow;
            }
            return Ok(await this.claimService.GetMemberClaimDetails(toDateBy));
        }
    }
}
