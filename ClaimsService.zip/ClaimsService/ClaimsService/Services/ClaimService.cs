﻿using ClaimsService.Models;
using CsvHelper;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClaimsService.Services
{
    public class ClaimService : IClaimService
    {
        private IHostingEnvironment _env;
        public ClaimService(IHostingEnvironment env)
        {
            _env = env;
        }

        public async Task<IEnumerable<MemberClaimDetails>> GetMemberClaimDetails(DateTime dateTime)
        {
            var membersDataTask = GetMembersData();
            var claimsDataTask = GetClaimsData();
            await Task.WhenAll(membersDataTask, claimsDataTask);

            var membersData = membersDataTask.Result;
            var claimsData = claimsDataTask.Result;

            var memberClaims = claimsData.Where(a => a.ClaimDate <= dateTime).Join(membersData, c => c.MemberID, m => m.MemberID, (c, m) => new
            {
                MemberID = m.MemberID,
                ClaimDate = c.ClaimDate,
                ClaimAmount = c.ClaimAmount,
                LastName = m.LastName,
                FirstName = m.FirstName,
                EnrollmentDate = m.EnrollmentDate
            }).GroupBy(a => a.MemberID);

            return memberClaims.Select(a => new MemberClaimDetails
            {
                MemberID = a.Key,
                FirstName = a.ToList()[0].FirstName,
                LastName = a.ToList()[0].LastName,
                EnrollmentDate = a.ToList()[0].EnrollmentDate,
                ClaimDetails = a.Select(c => new ClaimDetails
                {
                    ClaimAmount = c.ClaimAmount,
                    ClaimDate = c.ClaimDate
                })
            });
        }

        private Task<List<MemberModel>> GetMembersData()
        {
            List<MemberModel> memberModels = new List<MemberModel>();
            using (var reader = new StreamReader(System.IO.Path.Combine(_env.WebRootPath, "data", "Member.csv")))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var record = new MemberModel();
                var records = csv.EnumerateRecords(record);
                foreach (var r in records)
                {
                    memberModels.Add(new MemberModel { MemberID = r.MemberID, EnrollmentDate = r.EnrollmentDate, FirstName = r.FirstName, LastName = r.LastName });
                }
            }
            return Task.FromResult(memberModels);
        }

        private Task<List<ClaimModel>> GetClaimsData()
        {
            List<ClaimModel> claimModels = new List<ClaimModel>();
            using (var reader = new StreamReader(System.IO.Path.Combine(_env.WebRootPath, "data", "Claim.csv")))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                var record = new ClaimModel();
                var records = csv.EnumerateRecords(record);
                foreach (var r in records)
                {
                    claimModels.Add(new ClaimModel { ClaimAmount = r.ClaimAmount, ClaimDate = r.ClaimDate, MemberID = r.MemberID });
                }
            }

            return Task.FromResult(claimModels);
        }
    }
}
