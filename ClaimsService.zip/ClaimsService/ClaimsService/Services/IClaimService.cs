﻿using ClaimsService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsService.Services
{
    public interface IClaimService
    {
        Task<IEnumerable<MemberClaimDetails>> GetMemberClaimDetails(DateTime dateTime);
    }
}
