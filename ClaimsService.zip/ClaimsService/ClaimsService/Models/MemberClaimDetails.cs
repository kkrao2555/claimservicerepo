﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsService.Models
{
    public class MemberClaimDetails: MemberModel
    {
        public IEnumerable<ClaimDetails> ClaimDetails { get; set; }
    }
    public class ClaimDetails
    {
        public DateTime ClaimDate { get; set; }
        public double ClaimAmount { get; set; }
    }
}
