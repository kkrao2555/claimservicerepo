﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClaimsService.Models
{
    public class ClaimModel
    {
        public int MemberID { get; set; }
        public DateTime ClaimDate { get; set; }
        public double ClaimAmount { get; set; }
    }
}
